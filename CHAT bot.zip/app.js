  function talk() {
  var know = {
    "You like me":"Yeah why not ",
    "which country is also know as golden bird":"India ia lso know as golden bird ",
    
   "bread is always good with":"soup ",
  "hello":"hii ",
  
  "who invent gravity":" sir isaac newton invent gravity ",
  
  "what you like most":"i love everything   ",
  
     "tell me a joke":"mom: what was the smallest thing in this world me: your brain",
  
    "you are angry":"no i'am not angry, i'am so happy ",
    
 "in which age we are teenager":"in the age of 10-14 is young teen ager after the age of 14 we are teenager.  ",
    "who invent the vaccine of small pox":"edward jenner invent the vaccine of small pox ",
    
    
    "what is drink of india":"lassi is drink of india ",
"how many seconds in one day":"there are 82000 seconds in one day ",
"brinjal is fruit or vegiteble": "brinjal is fruit ",
    "which is Queen of bird": "peacock ",
    "who like you": "i dont know some peapole like me and some peapole hate me ",
    "who made the world": "bhrama the creater  made the world ",
    "which is king of fruits": "mango is king of fruits. ",
    "what is weather": "whether is day by day change of atmostphere. ",
    "wheare you live": "I live in your pocket ",
    "who devolop you": "anobl team made me ",
    "what is your name": "My name is slora ",
    "who are you": "Hello, slora here ",
    "how are you": "Good :)",
    "what can i do for you": "Please Give us A Follow & Like.",
    "your followers": "I have my family of 50000 members, i don't have follower ,have supportive Famiy ",
    
   
    
    
    
    
    
    
    "Hellow":"hii ",
    
    "Who invent gravity":"sir isaac newton invent gravity ",
    "Bread is always good with":"soup ",
    
    "In which age we are teenager":"in the age of 10-14 is young teen ager after the age of 14 we are teenager. ",
    
    "You are angry":"no i'am not angry, i'am so happy ",
    
    "Who invent the vaccine of small pox":"edward jenner invent the vaccine of small pox ",
    
    "What you like most":"i like everything ",
    
    "What is drink of india":"lassi is drink of india ",
    "How many seconds in one day":"there are 82000 seconds in a day ",
    "Brinjal is fruit or vegiteble":"brinjal is fruit ",
    "Which is Queen of bird":"peacock ",
    "Who like you":"i dont know some peapole like me and some peapole hate me ",
    "Who made the world":"bhrama the creater  made the world ",
    "Which is king of fruits":"mango is king of fruits. ",
    "What is weather":"whether is day by day change of atmostphere. ",
    "Wheare you live":"I live in your pocket ",
    "Who devolop you":"anobel team made me ",
    "What is your name":"My name is slora ",
    "Who are you": "Hello, slora here ",
    "How are you": "Good :)",
    "What can i do for you": "Please Give us A Follow & Like.",
    "Your followers": "I have my family of 50000 members, i don't have follower ,have supportive Family ",
    "ok": "Thank You So Much ",
    "Bye": "Okay! Will meet soon.."
  };
  var user = document.getElementById('userBox').value;
  document.getElementById('chatLog').innerHTML = user + "<br>";
  if (user in know) {
    document.getElementById('chatLog').innerHTML = know[user] + "<br>";
  } else {
    document.getElementById('chatLog').innerHTML = "Sorry,I didn't understand <br>";
  }
}