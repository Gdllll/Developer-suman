# Animated Search Bar
## [Watch it on youtube](https://youtu.be/TFXfpSjgI8Y)
### Animated Search Bar

- Animated Search Bar Using HTML CSS & JavaScript
- Contains animations when expanding the search bar.
- Change icon by clicking.
- You can type and search like a browser.
- With a beautiful minimalist interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
